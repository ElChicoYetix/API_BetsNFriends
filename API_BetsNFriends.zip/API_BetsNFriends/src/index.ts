import express from 'express';
import userRoutes from './routes/userRoutes';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
const exphbs = require('express-handlebars'); // Importación ajustada

dotenv.config();

const app = express();

app.use('/users', userRoutes);

// Configuración de Handlebars
app.engine('handlebars', exphbs({ defaultLayout: 'main' }));
app.set('view engine', 'handlebars');

// Definir la ruta para servir archivos estáticos (como CSS, imágenes, etc.)
app.use(express.static('public'));

// Conexión a MongoDB
mongoose.connect(process.env.MONGODB_URI as string)
  .then(() => console.log('Conexión a MongoDB exitosa'))
  .catch(err => console.error('Error al conectar a MongoDB', err));

const port = process.env.PORT || 3000;

const router = require('express').Router();
const path = require('path');

app.listen(port, () => {
    console.log(`App running en el puerto ${port}`);
});

// Ruta raíz 
router.get('/', (req: express.Request, res: express.Response) => {
  res.render('index', {
      title: 'Titulo dinamico'
  });
});

// Ruta para manejar el inicio de sesión
router.get('/login', (req: express.Request, res: express.Response) => {
  res.render('login');
});

// Ruta para la página de registro
router.get('/register', (req: express.Request, res: express.Response) => {
  res.render('register');
});
