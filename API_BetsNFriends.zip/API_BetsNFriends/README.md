# API_BetsNFriends
Proyecto de TECNOLOGIAS DE DESARROLLO EN EL SERVIDOR

Bets n’ friends

La idea principal del proyecto consiste en realizar una red social donde puedas chatear con tus amigos y, del mismo modo, realizar apuestas de manera “friendly” con los partidos más importantes de la semana. Se tendrá un score de cuanto quieres apostar y el otro usuario indicará si quiere aumentar la apuesta o igualarla, así hasta que ambos lleguen a un acuerdo. Se planea implementar mecánicas o estadísticas para fomentar la interacción entre los usuarios.

Integrantes:

  * Andre Yahir Gonzalez Cuevas
  
  * Carlos Emiliano Rodríguez Núñez

Conexión MongoDB

* Usuario: andre_owner, emi_owner

* Contraseña: proyecto1desarrollo
